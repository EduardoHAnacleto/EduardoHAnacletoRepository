﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoEduardoAnacletoWindowsForm1.Utility
{
    public class TaxesCalculator
    {
        public double WorkTax(double x, double y)
        {
            return x * y;
        }
    }
}
