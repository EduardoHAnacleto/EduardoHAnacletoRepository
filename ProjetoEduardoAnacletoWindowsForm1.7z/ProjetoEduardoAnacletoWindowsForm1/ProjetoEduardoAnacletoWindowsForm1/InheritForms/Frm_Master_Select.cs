﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoEduardoAnacletoWindowsForm1.InheritForms
{
    public partial class Frm_Master_Select : ProjetoEduardoAnacletoWindowsForm1.InheritForms.Frm_Base
    {
        public Frm_Master_Select()
        {
            InitializeComponent();
        }
    }
}
