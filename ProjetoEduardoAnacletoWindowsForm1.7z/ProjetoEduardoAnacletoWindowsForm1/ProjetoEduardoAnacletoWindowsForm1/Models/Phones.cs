﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoEduardoAnacletoWindowsForm1.Models
{
    public class Phones : Identifications
    {
        public Phones()
        {

        }

        public enum phoneClass
        {
            PersonalPhone = 1,
            WorkPhone = 2,
            HousePhone = 3,
            ParentsPhone = 4,
            RelativesPhone = 5,
            FriendlyPhone = 6,
            NoPhone = 7
            
        }

        public int ownerId { get; set; }
        public phoneClass phoneClassification { get; set; }
        public string phoneNumber { get; set; }
    }
}
