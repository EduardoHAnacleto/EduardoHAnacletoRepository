﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoEduardoAnacletoWindowsForm1.FormsCreate
{
    public partial class Frm_Create_Clients_Natural : ProjetoEduardoAnacletoWindowsForm1.InheritForms.Frm_Create_Master
    {
        public Frm_Create_Clients_Natural()
        {
            InitializeComponent();
        }

        private void rbtn_otherGender_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void medt_dob_Leave(object sender, EventArgs e)
        {
            //edt_age.Text = medt_dob.TextMaskFormat - DateTime.Now;
        }
    }
}
