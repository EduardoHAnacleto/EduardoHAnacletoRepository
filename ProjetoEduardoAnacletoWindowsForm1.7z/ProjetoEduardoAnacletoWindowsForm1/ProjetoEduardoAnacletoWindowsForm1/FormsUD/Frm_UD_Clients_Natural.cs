﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoEduardoAnacletoWindowsForm1.FormsUD
{
    public partial class Frm_UD_Clients_Natural : ProjetoEduardoAnacletoWindowsForm1.InheritForms.Frm_UD_Master
    {
        public Frm_UD_Clients_Natural()
        {
            InitializeComponent();
        }
    }
}
